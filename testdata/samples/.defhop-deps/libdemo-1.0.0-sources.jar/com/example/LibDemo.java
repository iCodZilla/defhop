package com.example;
public class LibDemo {
  public void hello() {}
}
